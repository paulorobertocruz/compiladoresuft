# compiladoresuft
Trabalhos de Compiladores

##Como Executar

pip install -r requirements.txt
export FLASK_APP=webapp.py
flask run

